package com.kraeutertee.api

import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.concurrent.TimeUnit

// ══════════════════════════════════════════════════════════════════════════════
// Gemini REST API Models
// ══════════════════════════════════════════════════════════════════════════════

data class GeminiRequest(
    @SerializedName("system_instruction")
    val systemInstruction: GeminiSystemInstruction? = null,
    val contents: List<GeminiContent>,
    @SerializedName("generationConfig")
    val generationConfig: GeminiGenerationConfig = GeminiGenerationConfig()
)

data class GeminiSystemInstruction(
    val parts: List<GeminiPart>
)

data class GeminiContent(
    val role: String,   // "user" or "model"
    val parts: List<GeminiPart>
)

data class GeminiPart(
    val text: String
)

data class GeminiGenerationConfig(
    @SerializedName("maxOutputTokens")
    val maxOutputTokens: Int = 1024,
    val temperature: Float = 0.7f
)

data class GeminiResponse(
    val candidates: List<GeminiCandidate>?,
    val error: GeminiError?
)

data class GeminiCandidate(
    val content: GeminiContent?,
    @SerializedName("finishReason")
    val finishReason: String?
)

data class GeminiError(
    val code: Int,
    val message: String,
    val status: String
)

// ══════════════════════════════════════════════════════════════════════════════
// Shared result type
// ══════════════════════════════════════════════════════════════════════════════

sealed class ApiResult<out T> {
    data class Success<T>(val data: T) : ApiResult<T>()
    data class Error(val message: String) : ApiResult<Nothing>()
}

// ══════════════════════════════════════════════════════════════════════════════
// GeminiService
// ══════════════════════════════════════════════════════════════════════════════

class GeminiService(private val apiKey: String) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private val gson = Gson()
    private val JSON = "application/json; charset=utf-8".toMediaType()

    // Gemini 2.0 Flash – fast, capable, free tier available
    private val modelEndpoint =
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent"

    // ── Core request ───────────────────────────────────────────────────────────

    private suspend fun generate(
        systemPrompt: String?,
        contents: List<GeminiContent>,
        maxTokens: Int = 1024
    ): ApiResult<String> = withContext(Dispatchers.IO) {

        if (apiKey.isBlank()) {
            return@withContext ApiResult.Error(
                "Kein API-Schlüssel konfiguriert. Bitte in den Einstellungen (⚙️) den Gemini API-Schlüssel eingeben."
            )
        }

        val requestBody = GeminiRequest(
            systemInstruction = systemPrompt?.let {
                GeminiSystemInstruction(parts = listOf(GeminiPart(it)))
            },
            contents = contents,
            generationConfig = GeminiGenerationConfig(maxOutputTokens = maxTokens)
        )

        val body = gson.toJson(requestBody).toRequestBody(JSON)

        val httpRequest = Request.Builder()
            .url("$modelEndpoint?key=$apiKey")
            .post(body)
            .build()

        try {
            val response = client.newCall(httpRequest).execute()
            val responseText = response.body?.string() ?: ""

            if (response.isSuccessful) {
                val parsed = gson.fromJson(responseText, GeminiResponse::class.java)
                val text = parsed.candidates
                    ?.firstOrNull()
                    ?.content
                    ?.parts
                    ?.firstOrNull()
                    ?.text
                    ?: return@withContext ApiResult.Error("Leere Antwort vom Server.")
                ApiResult.Success(text)
            } else {
                val parsed = runCatching {
                    gson.fromJson(responseText, GeminiResponse::class.java)
                }.getOrNull()
                val errMsg = parsed?.error?.message ?: responseText
                ApiResult.Error("Fehler ${response.code}: $errMsg")
            }
        } catch (e: IOException) {
            ApiResult.Error("Netzwerkfehler: ${e.localizedMessage ?: e.message}")
        }
    }

    // Convenience: single user turn
    private suspend fun chat(
        systemPrompt: String,
        userMessage: String,
        maxTokens: Int = 1024
    ): ApiResult<String> = generate(
        systemPrompt = systemPrompt,
        contents = listOf(GeminiContent("user", listOf(GeminiPart(userMessage)))),
        maxTokens = maxTokens
    )

    // ── Domain methods ─────────────────────────────────────────────────────────

    suspend fun explainHerb(herbName: String, latinName: String): ApiResult<String> = chat(
        systemPrompt = """Du bist ein erfahrener Kräuterkundler und Naturheilkundler.
Du erklärst Kräuter auf Deutsch, klar, verständlich und praxisnah.
Struktur: 1) Wirkung & Inhaltsstoffe, 2) Verwendung als Tee, 3) Besonderheiten & Tipps.
Maximal 300 Wörter. Keine Markdown-Überschriften.""",
        userMessage = "Erkläre mir das Kraut '$herbName' ($latinName) für die Teezubereitung.",
        maxTokens = 512
    )

    suspend fun suggestTeaBlends(availableHerbs: List<String>): ApiResult<String> = chat(
        systemPrompt = """Du bist ein Teemeister der Kräuterküche.
Antworte auf Deutsch. Schlage konkrete Teemischungen vor mit Verhältnis, Wirkung, Zubereitungstipp.
Maximal 400 Wörter.""",
        userMessage = """Mir stehen folgende Kräuter zur Verfügung: ${availableHerbs.joinToString(", ")}.
Empfiehl 3–5 harmonische Teemischungen. Gib jeweils Name, Zutaten mit Verhältnis, Wirkung und Tipp.""",
        maxTokens = 700
    )

    /**
     * Multi-turn chat.
     * [messages] contains (role, content) pairs where role is "user" or "assistant".
     * Gemini uses "model" instead of "assistant" – this is handled internally.
     */
    suspend fun getChatResponse(
        messages: List<Pair<String, String>>,
        herbContext: String = ""
    ): ApiResult<String> {

        if (apiKey.isBlank()) {
            return ApiResult.Error(
                "Kein API-Schlüssel konfiguriert. Bitte in den Einstellungen (⚙️) eingeben."
            )
        }

        val systemPrompt = buildString {
            append(
                """Du bist ein freundlicher und sachkundiger Kräuterexperte und Teemeister.
Du hilfst beim Sammeln, Trocknen, Zubereiten und Kombinieren von Kräutertees.
Antworte stets auf Deutsch, freundlich, praxisnah und klar.
Bei medizinischen Fragen weise auf einen Arzt hin."""
            )
            if (herbContext.isNotBlank()) {
                append("\nVerfügbare Kräuter des Nutzers: $herbContext")
            }
        }

        // Convert "assistant" → "model" for Gemini
        val contents = messages.map { (role, content) ->
            GeminiContent(
                role = if (role == "assistant") "model" else "user",
                parts = listOf(GeminiPart(content))
            )
        }

        // Gemini requires conversation to start with "user" and alternate
        // Filter out any leading "model" turns to be safe
        val sanitized = contents.dropWhile { it.role == "model" }

        return generate(systemPrompt, sanitized, maxTokens = 1024)
    }
}
