package com.kraeutertee.viewmodel

import android.content.Context
import androidx.lifecycle.*
import com.kraeutertee.api.ApiResult
import com.kraeutertee.api.GeminiService
import com.kraeutertee.data.AppDatabase
import com.kraeutertee.data.entities.*
import com.kraeutertee.ui.screens.ChatMessage
import com.kraeutertee.util.*
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

// ══════════════════════════════════════════════════════════════════════════════
// HerbsViewModel
// ══════════════════════════════════════════════════════════════════════════════
class HerbsViewModel(app: android.app.Application) : AndroidViewModel(app) {

    private val db    = AppDatabase.getInstance(app)
    private val prefs = PreferencesManager(app)

    val searchQuery      = MutableStateFlow("")
    val selectedCategory = MutableStateFlow<String?>(null)
    val gardenFilter     = MutableStateFlow(false)
    val aiExplanation    = MutableStateFlow("")
    val isLoading        = MutableStateFlow(false)
    val harmonizingResult = MutableStateFlow("")

    val filteredHerbs: StateFlow<List<HerbInfo>> = combine(
        searchQuery,
        selectedCategory,
        gardenFilter,
        db.herbNoteDao().getAll()
    ) { q, cat, gardenOnly, notes ->
        val gardenIds = notes.filter { it.isInGarden }.map { it.herbId }.toSet()
        HerbDatabase.all.filter { herb ->
            (q.isBlank()
                    || herb.name.contains(q, ignoreCase = true)
                    || herb.latinName.contains(q, ignoreCase = true)
                    || herb.effects.any { it.contains(q, ignoreCase = true) })
                    && (cat == null || herb.category == cat)
                    && (!gardenOnly || herb.id in gardenIds)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HerbDatabase.all)

    fun setSearch(q: String)        { searchQuery.value = q }
    fun setCategory(cat: String?)   { selectedCategory.value = cat }
    fun setGardenFilter(v: Boolean) { gardenFilter.value = v }

    fun getNoteFor(herbId: String): Flow<HerbNote?> =
        db.herbNoteDao().getAll().map { list -> list.find { it.herbId == herbId } }

    fun toggleFavorite(herbId: String, current: HerbNote?) = viewModelScope.launch {
        val note = current ?: HerbNote(herbId = herbId)
        db.herbNoteDao().upsert(note.copy(isFavorite = !note.isFavorite))
    }

    fun toggleGarden(herbId: String, current: HerbNote?) = viewModelScope.launch {
        val note = current ?: HerbNote(herbId = herbId)
        db.herbNoteDao().upsert(note.copy(isInGarden = !note.isInGarden))
    }

    fun saveNotes(herbId: String, notes: String, current: HerbNote?) = viewModelScope.launch {
        val note = current ?: HerbNote(herbId = herbId)
        db.herbNoteDao().upsert(
            note.copy(personalNotes = notes, lastUpdated = System.currentTimeMillis())
        )
    }

    fun loadAiExplanation(herb: HerbInfo) = viewModelScope.launch {
        isLoading.value = true
        aiExplanation.value = ""
        val key    = prefs.apiKey.first()
        val result = GeminiService(key).explainHerb(herb.name, herb.latinName)
        aiExplanation.value = when (result) {
            is ApiResult.Success -> result.data
            is ApiResult.Error   -> "Fehler: ${result.message}"
        }
        isLoading.value = false
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// MapViewModel
// ══════════════════════════════════════════════════════════════════════════════
class MapViewModel(app: android.app.Application) : AndroidViewModel(app) {

    private val db    = AppDatabase.getInstance(app)
    private val prefs = PreferencesManager(app)

    val allLocations = db.herbLocationDao().getAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val latitude         = MutableStateFlow(48.1374)
    val longitude        = MutableStateFlow(11.5755)
    val selectedLocation = MutableStateFlow<HerbLocation?>(null)

    init {
        viewModelScope.launch {
            prefs.lastLocation.collect { (lat, lng) ->
                latitude.value  = lat
                longitude.value = lng
            }
        }
    }

    fun refreshLocation(context: Context) = viewModelScope.launch {
        LocationHelper.getLastLocation(context)?.let { loc ->
            latitude.value  = loc.latitude
            longitude.value = loc.longitude
            prefs.saveLocation(loc.latitude, loc.longitude)
        }
    }

    fun addLocation(loc: HerbLocation) = viewModelScope.launch {
        db.herbLocationDao().insert(loc)
    }

    fun deleteLocation(loc: HerbLocation) = viewModelScope.launch {
        db.herbLocationDao().delete(loc)
        if (selectedLocation.value?.id == loc.id) selectedLocation.value = null
    }

    fun selectLocation(loc: HerbLocation) { selectedLocation.value = loc }
}

// ══════════════════════════════════════════════════════════════════════════════
// CalendarViewModel
// ══════════════════════════════════════════════════════════════════════════════
class CalendarViewModel(app: android.app.Application) : AndroidViewModel(app) {

    private val db    = AppDatabase.getInstance(app)
    private val prefs = PreferencesManager(app)

    val activeReminders = db.harvestReminderDao().getActive()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val activeDrying = db.dryingEntryDao().getActive()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val allDrying = db.dryingEntryDao().getAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val latitude = MutableStateFlow(48.1374)

    init {
        viewModelScope.launch {
            prefs.lastLocation.collect { (lat, _) -> latitude.value = lat }
        }
    }

    fun refreshLocation(context: Context) = viewModelScope.launch {
        LocationHelper.getLastLocation(context)?.let { loc ->
            latitude.value = loc.latitude
            prefs.saveLocation(loc.latitude, loc.longitude)
        }
    }

    fun climateZoneName(lat: Double)   = LocationHelper.climateZoneName(lat)
    fun offsetDescription(lat: Double) = LocationHelper.harvestOffsetDescription(lat)

    fun addReminder(
        reminder: HarvestReminder,
        @Suppress("UNUSED_PARAMETER") context: Context
    ) = viewModelScope.launch {
        db.harvestReminderDao().insert(reminder)
    }

    fun deleteReminder(reminder: HarvestReminder) = viewModelScope.launch {
        db.harvestReminderDao().delete(reminder)
    }

    fun addDrying(entry: DryingEntry) = viewModelScope.launch {
        db.dryingEntryDao().insert(entry)
    }

    fun completeDrying(entry: DryingEntry) = viewModelScope.launch {
        db.dryingEntryDao().update(
            entry.copy(isCompleted = true, completedDate = System.currentTimeMillis())
        )
    }

    fun deleteDrying(entry: DryingEntry) = viewModelScope.launch {
        db.dryingEntryDao().delete(entry)
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// RecipesViewModel  – flatMapLatest requires @OptIn(ExperimentalCoroutinesApi)
// ══════════════════════════════════════════════════════════════════════════════
class RecipesViewModel(app: android.app.Application) : AndroidViewModel(app) {

    private val db = AppDatabase.getInstance(app)

    val searchQuery = MutableStateFlow("")

    @OptIn(ExperimentalCoroutinesApi::class)
    val recipes: StateFlow<List<Recipe>> = searchQuery
        .flatMapLatest { q ->
            if (q.isBlank()) db.recipeDao().getAll()
            else             db.recipeDao().search(q)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun setSearch(q: String) { searchQuery.value = q }

    fun addRecipe(recipe: Recipe) = viewModelScope.launch {
        db.recipeDao().insert(recipe)
    }

    fun updateRecipe(recipe: Recipe) = viewModelScope.launch {
        db.recipeDao().update(recipe.copy(updatedAt = System.currentTimeMillis()))
    }

    fun deleteRecipe(recipe: Recipe) = viewModelScope.launch {
        db.recipeDao().delete(recipe)
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// KIViewModel
// ══════════════════════════════════════════════════════════════════════════════
class KIViewModel(app: android.app.Application) : AndroidViewModel(app) {

    private val db    = AppDatabase.getInstance(app)
    private val prefs = PreferencesManager(app)

    val messages         = MutableStateFlow<List<ChatMessage>>(emptyList())
    val isLoading        = MutableStateFlow(false)
    val blendSuggestions = MutableStateFlow("")

    val hasApiKey: StateFlow<Boolean> = prefs.apiKey
        .map { it.isNotBlank() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), false)

    val gardenHerbNames: StateFlow<List<String>> = db.herbNoteDao().getGardenHerbs()
        .map { notes ->
            notes.mapNotNull { note -> HerbDatabase.getById(note.herbId)?.name }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun sendMessage(text: String) = viewModelScope.launch {
        val userMsg = ChatMessage("user", text)
        messages.value = messages.value + userMsg
        isLoading.value = true

        val key     = prefs.apiKey.first()
        val herbCtx = gardenHerbNames.value.joinToString(", ")
        // Pass full conversation history (including the just-added user message)
        val history = messages.value.map { Pair(it.role, it.content) }

        val result = GeminiService(key).getChatResponse(history, herbCtx)
        val response = when (result) {
            is ApiResult.Success -> ChatMessage("assistant", result.data)
            is ApiResult.Error   -> ChatMessage("assistant", "⚠️ ${result.message}", isError = true)
        }
        messages.value = messages.value + response
        isLoading.value = false
    }

    fun loadBlendSuggestions() = viewModelScope.launch {
        if (gardenHerbNames.value.isEmpty()) return@launch
        isLoading.value = true
        blendSuggestions.value = ""
        val key    = prefs.apiKey.first()
        val result = GeminiService(key).suggestTeaBlends(gardenHerbNames.value)
        blendSuggestions.value = when (result) {
            is ApiResult.Success -> result.data
            is ApiResult.Error   -> "⚠️ ${result.message}"
        }
        isLoading.value = false
    }

    fun clearChat() { messages.value = emptyList() }
}

// ══════════════════════════════════════════════════════════════════════════════
// SettingsViewModel
// ══════════════════════════════════════════════════════════════════════════════
class SettingsViewModel(app: android.app.Application) : AndroidViewModel(app) {

    private val prefs = PreferencesManager(app)

    val apiKey = prefs.apiKey
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), "")
    val notifyHarvest = prefs.notifyHarvest
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), true)
    val notifyDrying  = prefs.notifyDrying
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), true)
    val daysBefore    = prefs.notifyDaysBefore
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 3)

    fun saveApiKey(key: String)      = viewModelScope.launch { prefs.saveApiKey(key) }
    fun setNotifyHarvest(v: Boolean) = viewModelScope.launch { prefs.setNotifyHarvest(v) }
    fun setNotifyDrying(v: Boolean)  = viewModelScope.launch { prefs.setNotifyDrying(v) }
    fun setDaysBefore(days: Int)     = viewModelScope.launch { prefs.setNotifyDaysBefore(days) }
}

// ══════════════════════════════════════════════════════════════════════════════
// ViewModelFactory
// ══════════════════════════════════════════════════════════════════════════════
class AppViewModelFactory(
    private val app: android.app.Application
) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = when {
        modelClass.isAssignableFrom(HerbsViewModel::class.java)    -> HerbsViewModel(app)    as T
        modelClass.isAssignableFrom(MapViewModel::class.java)      -> MapViewModel(app)      as T
        modelClass.isAssignableFrom(CalendarViewModel::class.java) -> CalendarViewModel(app) as T
        modelClass.isAssignableFrom(RecipesViewModel::class.java)  -> RecipesViewModel(app)  as T
        modelClass.isAssignableFrom(KIViewModel::class.java)       -> KIViewModel(app)       as T
        modelClass.isAssignableFrom(SettingsViewModel::class.java) -> SettingsViewModel(app) as T
        else -> throw IllegalArgumentException("Unknown ViewModel: ${modelClass.name}")
    }
}
