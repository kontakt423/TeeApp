package com.kraeutertee.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import com.kraeutertee.data.entities.HerbNote
import com.kraeutertee.util.HerbDatabase
import com.kraeutertee.util.HerbInfo
import com.kraeutertee.viewmodel.HerbsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HerbsScreen(vm: HerbsViewModel, onNavigateToDetail: (String) -> Unit) {
    val searchQuery by vm.searchQuery.collectAsState()
    val selectedCategory by vm.selectedCategory.collectAsState()
    val filteredHerbs by vm.filteredHerbs.collectAsState()
    val gardenFilter by vm.gardenFilter.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {

        // ── Search bar ──────────────────────────────────────────────────────────
        OutlinedTextField(
            value = searchQuery,
            onValueChange = vm::setSearch,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            placeholder = { Text("Kräuter suchen…") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            trailingIcon = {
                if (searchQuery.isNotEmpty())
                    IconButton(onClick = { vm.setSearch("") }) {
                        Icon(Icons.Default.Clear, null)
                    }
            },
            singleLine = true,
            shape = RoundedCornerShape(28.dp)
        )

        // ── Category chips ──────────────────────────────────────────────────────
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp)
        ) {
            item {
                FilterChip(
                    selected = selectedCategory == null && !gardenFilter,
                    onClick = { vm.setCategory(null); vm.setGardenFilter(false) },
                    label = { Text("Alle") },
                    leadingIcon = if (selectedCategory == null && !gardenFilter) {
                        { Icon(Icons.Default.Check, null, Modifier.size(16.dp)) }
                    } else null
                )
            }
            item {
                FilterChip(
                    selected = gardenFilter,
                    onClick = { vm.setGardenFilter(!gardenFilter) },
                    label = { Text("🌱 Mein Garten") },
                    leadingIcon = if (gardenFilter) {
                        { Icon(Icons.Default.Check, null, Modifier.size(16.dp)) }
                    } else null
                )
            }
            items(HerbDatabase.categories) { cat ->
                FilterChip(
                    selected = selectedCategory == cat,
                    onClick = { vm.setCategory(if (selectedCategory == cat) null else cat) },
                    label = { Text(cat) },
                    leadingIcon = if (selectedCategory == cat) {
                        { Icon(Icons.Default.Check, null, Modifier.size(16.dp)) }
                    } else null
                )
            }
        }

        // ── Herb grid ───────────────────────────────────────────────────────────
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 160.dp),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(filteredHerbs, key = { it.id }) { herb ->
                val note = vm.getNoteFor(herb.id).collectAsState(initial = null).value
                HerbCard(
                    herb = herb,
                    note = note,
                    onClick = { onNavigateToDetail(herb.id) },
                    onToggleFavorite = { vm.toggleFavorite(herb.id, note) },
                    onToggleGarden = { vm.toggleGarden(herb.id, note) }
                )
            }
        }
    }
}

@Composable
private fun HerbCard(
    herb: HerbInfo,
    note: HerbNote?,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    onToggleGarden: () -> Unit
) {
    val isFav = note?.isFavorite == true
    val isGarden = note?.isInGarden == true

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isGarden)
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
            else MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {

            Row(verticalAlignment = Alignment.Top) {
                Text(herb.emoji, fontSize = 32.sp, modifier = Modifier.weight(1f))
                IconButton(onClick = onToggleFavorite, modifier = Modifier.size(28.dp)) {
                    Icon(
                        if (isFav) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Favorit",
                        tint = if (isFav) Color(0xFFE53935) else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(Modifier.height(4.dp))
            Text(
                herb.name,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                herb.latinName,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(6.dp))
            Text(
                herb.shortDescription,
                style = MaterialTheme.typography.bodySmall,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))

            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                SuggestionChip(
                    onClick = {},
                    label = { Text(herb.category, style = MaterialTheme.typography.labelSmall) },
                    modifier = Modifier.height(24.dp)
                )
                IconButton(
                    onClick = onToggleGarden,
                    modifier = Modifier.size(28.dp)
                ) {
                    Text(if (isGarden) "🌱" else "➕", fontSize = 14.sp)
                }
            }
        }
    }
}

// ── Herb Detail Screen ─────────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HerbDetailScreen(
    herbId: String,
    vm: HerbsViewModel,
    onBack: () -> Unit
) {
    val herb = remember(herbId) { HerbDatabase.getById(herbId) } ?: run {
        onBack(); return
    }
    val note by vm.getNoteFor(herbId).collectAsState(initial = null)
    val aiExplanation by vm.aiExplanation.collectAsState()
    val isLoading by vm.isLoading.collectAsState()

    LaunchedEffect(herbId) { vm.loadAiExplanation(herb) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("${herb.emoji} ${herb.name}") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Zurück") }
                },
                actions = {
                    IconButton(onClick = { vm.toggleFavorite(herbId, note) }) {
                        Icon(
                            if (note?.isFavorite == true) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            "Favorit",
                            tint = if (note?.isFavorite == true) Color(0xFFE53935)
                            else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = { vm.toggleGarden(herbId, note) }) {
                        Text(if (note?.isInGarden == true) "🌱" else "➕", fontSize = 18.sp)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {

            // Quick info chips
            item {
                InfoChipRow(herb)
            }

            // Harvest info
            item {
                DetailCard(title = "🌿 Ernte", icon = Icons.Default.ContentCut) {
                    LabeledRow("Teil:", herb.harvestPart)
                    LabeledRow("Monate:", herb.harvestMonths.joinToString(", ") { monthName(it) })
                    Spacer(Modifier.height(4.dp))
                    Text(herb.harvestTips, style = MaterialTheme.typography.bodyMedium)
                }
            }

            // Drying info
            item {
                DetailCard(title = "☀️ Trocknung", icon = Icons.Default.WbSunny) {
                    LabeledRow("Dauer:", "${herb.dryingDays} Tage")
                    LabeledRow("Max. Temp:", "${herb.dryingTempMax}°C")
                    LabeledRow("Lagerung:", "${herb.storageMonths} Monate")
                    Spacer(Modifier.height(4.dp))
                    Text(herb.dryingMethod, style = MaterialTheme.typography.bodyMedium)
                }
            }

            // Tea preparation
            item {
                DetailCard(title = "☕ Teezubereitung", icon = Icons.Default.LocalCafe) {
                    LabeledRow("Temperatur:", "${herb.brewingTempC}°C")
                    LabeledRow("Ziehzeit:", "${herb.brewingMinutes} Min.")
                    Spacer(Modifier.height(4.dp))
                    Text(herb.teaInfo, style = MaterialTheme.typography.bodyMedium)
                }
            }

            // Effects
            item {
                DetailCard(title = "✨ Wirkungen", icon = Icons.Default.AutoAwesome) {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        herb.effects.forEach { effect ->
                            SuggestionChip(onClick = {}, label = { Text(effect) })
                        }
                    }
                }
            }

            // Warnings
            if (herb.warningsDE.isNotBlank()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = Color(0xFFFFF3E0)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(Icons.Default.Warning, null,
                                tint = Color(0xFFF57C00),
                                modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(8.dp))
                            Column {
                                Text("Hinweis", fontWeight = FontWeight.Bold,
                                    color = Color(0xFF7F4800))
                                Text(herb.warningsDE, style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF7F4800))
                            }
                        }
                    }
                }
            }

            // AI Explanation
            item {
                DetailCard(title = "🤖 KI-Erklärung", icon = Icons.Default.SmartToy) {
                    if (isLoading) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.width(8.dp))
                            Text("Gemini erklärt…", style = MaterialTheme.typography.bodySmall)
                        }
                    } else if (aiExplanation.isNotBlank()) {
                        Text(aiExplanation, style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(onClick = { vm.loadAiExplanation(herb) }) {
                            Icon(Icons.Default.Refresh, null, Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Neu laden")
                        }
                    } else {
                        OutlinedButton(onClick = { vm.loadAiExplanation(herb) }) {
                            Icon(Icons.Default.SmartToy, null, Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("KI-Erklärung laden")
                        }
                    }
                }
            }

            // Personal notes
            item {
                val currentNotes = note?.personalNotes ?: ""
                var editNotes by remember { mutableStateOf(currentNotes) }
                var editing by remember { mutableStateOf(false) }

                DetailCard(title = "📝 Persönliche Notizen", icon = Icons.Default.Edit) {
                    if (editing) {
                        OutlinedTextField(
                            value = editNotes,
                            onValueChange = { editNotes = it },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("Deine Beobachtungen, Fundorte, Erfahrungen…") },
                            minLines = 3
                        )
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                            TextButton(onClick = { editing = false }) { Text("Abbrechen") }
                            Spacer(Modifier.width(8.dp))
                            Button(onClick = {
                                vm.saveNotes(herbId, editNotes, note)
                                editing = false
                            }) { Text("Speichern") }
                        }
                    } else {
                        if (currentNotes.isNotBlank()) {
                            Text(currentNotes, style = MaterialTheme.typography.bodyMedium)
                            Spacer(Modifier.height(8.dp))
                        } else {
                            Text("Noch keine Notizen.", color = MaterialTheme.colorScheme.onSurfaceVariant,
                                style = MaterialTheme.typography.bodySmall)
                            Spacer(Modifier.height(4.dp))
                        }
                        TextButton(onClick = { editNotes = currentNotes; editing = true }) {
                            Icon(Icons.Default.Edit, null, Modifier.size(14.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Notiz bearbeiten")
                        }
                    }
                }
            }

            item { Spacer(Modifier.height(80.dp)) }
        }
    }
}

// ── Helper composables ─────────────────────────────────────────────────────────

@Composable
private fun InfoChipRow(herb: HerbInfo) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        item {
            AssistChip(onClick = {}, label = { Text("${herb.harvestPart}") },
                leadingIcon = { Text("✂️", fontSize = 12.sp) })
        }
        item {
            AssistChip(onClick = {}, label = { Text("${herb.brewingTempC}°C") },
                leadingIcon = { Text("🌡️", fontSize = 12.sp) })
        }
        item {
            AssistChip(onClick = {}, label = { Text("${herb.brewingMinutes} Min.") },
                leadingIcon = { Text("⏱️", fontSize = 12.sp) })
        }
        item {
            AssistChip(onClick = {}, label = { Text("${herb.storageMonths}M Lager") },
                leadingIcon = { Text("🫙", fontSize = 12.sp) })
        }
    }
}

@Composable
private fun DetailCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
private fun LabeledRow(label: String, value: String) {
    Row(modifier = Modifier.padding(vertical = 2.dp)) {
        Text(label, fontWeight = FontWeight.Medium,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.width(90.dp),
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodySmall)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun FlowRow(
    horizontalArrangement: Arrangement.Horizontal,
    content: @Composable () -> Unit
) {
    androidx.compose.foundation.layout.FlowRow(
        horizontalArrangement = horizontalArrangement,
        verticalArrangement = Arrangement.spacedBy(4.dp),
        content = { content() }
    )
}

fun monthName(month: Int): String = when (month) {
    1 -> "Jan"; 2 -> "Feb"; 3 -> "Mär"; 4 -> "Apr"
    5 -> "Mai"; 6 -> "Jun"; 7 -> "Jul"; 8 -> "Aug"
    9 -> "Sep"; 10 -> "Okt"; 11 -> "Nov"; 12 -> "Dez"
    else -> "?"
}
