package com.kraeutertee.util

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import com.google.android.gms.location.*
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

object LocationHelper {

    /**
     * Returns latitude offset in months relative to Central European baseline (48–54°N).
     *   > 60°N → +2 (Scandinavia, very late)
     *   54–60°N → +1 (North Germany, Northern Europe)
     *   48–54°N → 0  (Central Europe, baseline)
     *   42–48°N → -1 (Southern Germany, Austria, Switzerland)
     *   < 42°N  → -2 (Mediterranean)
     */
    fun harvestLatitudeOffset(latitude: Double): Int = when {
        latitude > 60.0  ->  2
        latitude > 54.0  ->  1
        latitude > 48.0  ->  0
        latitude > 42.0  -> -1
        else             -> -2
    }

    fun climateZoneName(latitude: Double): String = when {
        latitude > 60.0 -> "Skandinavisch (> 60°N)"
        latitude > 54.0 -> "Norddeutschland / Nordeuropa"
        latitude > 48.0 -> "Mitteleuropa (Baseline)"
        latitude > 42.0 -> "Süddeutschland / Österreich / Schweiz"
        else            -> "Mediterran"
    }

    fun harvestOffsetDescription(latitude: Double): String {
        val offset = harvestLatitudeOffset(latitude)
        return when {
            offset > 0 -> "Ernte ca. $offset Monat${if (offset > 1) "e" else ""} später als Mitteleuropa"
            offset < 0 -> "Ernte ca. ${-offset} Monat${if (-offset > 1) "e" else ""} früher als Mitteleuropa"
            else -> "Mitteleuropäischer Erntezeitraum"
        }
    }

    @SuppressLint("MissingPermission")
    suspend fun getLastLocation(context: Context): Location? =
        suspendCancellableCoroutine { cont ->
            val client = LocationServices.getFusedLocationProviderClient(context)
            client.lastLocation
                .addOnSuccessListener { location -> cont.resume(location) }
                .addOnFailureListener { e -> cont.resumeWithException(e) }
        }

    @SuppressLint("MissingPermission")
    suspend fun getCurrentLocation(context: Context): Location? =
        suspendCancellableCoroutine { cont ->
            val client = LocationServices.getFusedLocationProviderClient(context)
            val request = CurrentLocationRequest.Builder()
                .setPriority(Priority.PRIORITY_BALANCED_POWER_ACCURACY)
                .build()
            client.getCurrentLocation(request, null)
                .addOnSuccessListener { location -> cont.resume(location) }
                .addOnFailureListener { cont.resume(null) }
        }
}
